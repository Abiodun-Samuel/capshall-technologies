1. clone the repo
   run "composer install --ignore-platform-reqs" command
2. Create a database "capshall"
3. Add database user name "capshall"
4. Add database password "capshall"
5. Run command "php artisan migrate"
6. export the "capshall.sql" file into the database.
7. Run command "php artisan serve"
